# NewsBrief
As the world’s technology is rapidly growing, we have a fast connection and network to instantly connect to another person. Day-to-day use of smart devices is increasing, and people already have these facilities. In this fast and information-oriented world, we need to stay updated with every incident and daily updates. This News app is a mobile application where users have access to the latest news from newspapers and media. The main purpose of this application is to provide personalized news feeds from all around the world. 

![Screenshot 2023-02-03 200940](https://user-images.githubusercontent.com/80467294/216631884-b28c4035-e43e-42ad-90ec-f10b4c4a68b9.jpg)

**Home Page**

![Screenshot 2023-02-03 202119](https://user-images.githubusercontent.com/80467294/216633566-024c3d7d-e519-43f5-8864-d21bd48a1731.jpg)

**Highlights**
